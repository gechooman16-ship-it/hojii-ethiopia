import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:file_picker/file_picker.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import '../services/cv_service.dart';
import 'package:url_launcher/url_launcher.dart';

class CvPage extends StatefulWidget {
  const CvPage({super.key});
  @override
  State<CvPage> createState() => _CvPageState();
}

class _CvPageState extends State<CvPage> {
  bool loading = false;
  String cvUrl = '';

  Future<void> load() async {
    final uid = FirebaseAuth.instance.currentUser?.uid;
    if (uid == null) return;
    final doc = await FirebaseFirestore.instance.collection('users').doc(uid).get();
    if (mounted) setState(() => cvUrl = doc.data()?['cvUrl'] ?? '');
  }

  Future<void> upload() async {
    final result = await FilePicker.platform.pickFiles(type: FileType.custom, allowedExtensions: ['pdf'], withData: true);
    if (result == null || result.files.single.bytes == null) return;
    setState(() => loading = true);
    try {
      final url = await CvService().uploadCv(bytes: result.files.single.bytes!);
      final uid = FirebaseAuth.instance.currentUser!.uid;
      await FirebaseFirestore.instance.collection('users').doc(uid).update({
        'cvUrl': url, 'cvFileName': result.files.single.name,
      });
      setState(() => cvUrl = url);
    } catch (e) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('$e')));
    } finally {
      if (mounted) setState(() => loading = false);
    }
  }

  Future<void> delete() async {
    await CvService().deleteCv();
    final uid = FirebaseAuth.instance.currentUser!.uid;
    await FirebaseFirestore.instance.collection('users').doc(uid).update({'cvUrl': '', 'cvFileName': ''});
    setState(() => cvUrl = '');
  }

  @override
  void initState() { super.initState(); load(); }

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('My CV')),
    body: Padding(padding: const EdgeInsets.all(20), child: Column(children: [
      const Icon(Icons.picture_as_pdf, size: 80),
      const SizedBox(height: 15),
      Text(cvUrl.isEmpty ? 'CV hin qabdu' : 'CV kee upload taʼeera'),
      const SizedBox(height: 20),
      SizedBox(width: double.infinity, height: 52, child: FilledButton.icon(
        onPressed: loading ? null : upload,
        icon: const Icon(Icons.upload_file),
        label: Text(loading ? 'Uploading...' : 'Choose CV PDF'),
      )),
      if (cvUrl.isNotEmpty) ...[
        const SizedBox(height: 12),
        OutlinedButton.icon(onPressed: () => launchUrl(Uri.parse(cvUrl), mode: LaunchMode.externalApplication),
          icon: const Icon(Icons.visibility), label: const Text('View CV')),
        TextButton.icon(onPressed: delete, icon: const Icon(Icons.delete), label: const Text('Delete CV')),
      ],
    ])),
  );
}
