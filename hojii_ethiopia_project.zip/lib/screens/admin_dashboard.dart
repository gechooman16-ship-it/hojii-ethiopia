import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';

class AdminDashboard extends StatelessWidget {
  const AdminDashboard({super.key});

  Widget count(String title, String collection, IconData icon) {
    return StreamBuilder<QuerySnapshot>(
      stream: FirebaseFirestore.instance.collection(collection).snapshots(),
      builder: (_, snap) => Card(child: ListTile(
        leading: Icon(icon, size: 30), title: Text(title),
        trailing: Text('${snap.data?.docs.length ?? 0}', style: const TextStyle(fontSize: 22, fontWeight: FontWeight.bold)),
      )),
    );
  }

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('Admin Dashboard'), actions: [
      IconButton(icon: const Icon(Icons.logout), onPressed: () => FirebaseAuth.instance.signOut())
    ]),
    body: ListView(padding: const EdgeInsets.all(16), children: [
      count('Users', 'users', Icons.people),
      count('Jobs', 'jobs', Icons.work),
      count('Applications', 'applications', Icons.description),
      count('Payments', 'payments', Icons.payment),
    ]),
  );
}
