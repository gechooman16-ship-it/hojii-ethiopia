import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'job_details_page.dart';
import 'my_applications_page.dart';
import 'cv_page.dart';

class HomePage extends StatelessWidget {
  const HomePage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Hojii Ethiopia'),
        actions: [
          IconButton(icon: const Icon(Icons.description), onPressed: () {
            Navigator.push(context, MaterialPageRoute(builder: (_) => const MyApplicationsPage()));
          }),
          IconButton(icon: const Icon(Icons.person), onPressed: () {
            Navigator.push(context, MaterialPageRoute(builder: (_) => const CvPage()));
          }),
          IconButton(icon: const Icon(Icons.logout), onPressed: () => FirebaseAuth.instance.signOut()),
        ],
      ),
      body: StreamBuilder<QuerySnapshot<Map<String, dynamic>>>(
        stream: FirebaseFirestore.instance.collection('jobs').orderBy('createdAt', descending: true).snapshots(),
        builder: (context, snap) {
          if (snap.connectionState == ConnectionState.waiting) {
            return const Center(child: CircularProgressIndicator());
          }
          if (snap.hasError) return Center(child: Text('Error: ${snap.error}'));
          final jobs = snap.data?.docs ?? [];
          if (jobs.isEmpty) return const Center(child: Text('Hanga amma hojii hin jiru.'));
          return ListView.builder(
            padding: const EdgeInsets.all(12),
            itemCount: jobs.length,
            itemBuilder: (_, i) {
              final data = jobs[i].data();
              return Card(
                child: ListTile(
                  leading: CircleAvatar(child: Icon(data['isPremium'] == true ? Icons.star : Icons.work)),
                  title: Text(data['title'] ?? 'Job'),
                  subtitle: Text('${data['company'] ?? ''} • ${data['location'] ?? ''}'),
                  trailing: data['isPremium'] == true ? const Chip(label: Text('PREMIUM')) : null,
                  onTap: () => Navigator.push(context, MaterialPageRoute(
                    builder: (_) => JobDetailsPage(jobId: jobs[i].id, data: data),
                  )),
                ),
              );
            },
          );
        },
      ),
    );
  }
}
