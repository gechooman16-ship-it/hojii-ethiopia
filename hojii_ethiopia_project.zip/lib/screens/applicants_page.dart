import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';

class ApplicantsPage extends StatelessWidget {
  final String jobId;
  const ApplicantsPage({super.key, required this.jobId});

  Future<void> status(String id, String value) => FirebaseFirestore.instance.collection('applications').doc(id).update({
    'status': value, 'updatedAt': FieldValue.serverTimestamp(),
  });

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('Applicants')),
    body: StreamBuilder<QuerySnapshot<Map<String, dynamic>>>(
      stream: FirebaseFirestore.instance.collection('applications').where('jobId', isEqualTo: jobId).snapshots(),
      builder: (_, snap) {
        if (!snap.hasData) return const Center(child: CircularProgressIndicator());
        final docs = snap.data!.docs;
        if (docs.isEmpty) return const Center(child: Text('Applicant hin jiru.'));
        return ListView.builder(padding: const EdgeInsets.all(12), itemCount: docs.length, itemBuilder: (_, i) {
          final d = docs[i].data();
          final cv = d['cvUrl'] ?? '';
          return Card(child: Padding(padding: const EdgeInsets.all(12), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text(d['applicantName'] ?? '', style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 18)),
            Text(d['applicantEmail'] ?? ''),
            Text('Status: ${d['status'] ?? 'pending'}'),
            Row(children: [
              if (cv.toString().isNotEmpty) OutlinedButton.icon(
                onPressed: () => launchUrl(Uri.parse(cv), mode: LaunchMode.externalApplication),
                icon: const Icon(Icons.description), label: const Text('View CV')),
              const Spacer(),
              IconButton(onPressed: () => status(docs[i].id, 'accepted'), icon: const Icon(Icons.check)),
              IconButton(onPressed: () => status(docs[i].id, 'rejected'), icon: const Icon(Icons.close)),
            ]),
          ])));
        });
      },
    ),
  );
}
