import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import '../services/apply_service.dart';
import 'cv_page.dart';

class JobDetailsPage extends StatefulWidget {
  final String jobId;
  final Map<String, dynamic> data;
  const JobDetailsPage({super.key, required this.jobId, required this.data});
  @override
  State<JobDetailsPage> createState() => _JobDetailsPageState();
}

class _JobDetailsPageState extends State<JobDetailsPage> {
  bool loading = false;

  Future<void> apply() async {
    setState(() => loading = true);
    try {
      final uid = FirebaseAuth.instance.currentUser!.uid;
      final userDoc = await FirebaseFirestore.instance.collection('users').doc(uid).get();
      final u = userDoc.data() ?? {};
      final cvUrl = u['cvUrl'] ?? '';
      if (cvUrl.toString().isEmpty) {
        if (!mounted) return;
        await Navigator.push(context, MaterialPageRoute(builder: (_) => const CvPage()));
        final refreshed = await FirebaseFirestore.instance.collection('users').doc(uid).get();
        final newCv = refreshed.data()?['cvUrl'] ?? '';
        if (newCv.toString().isEmpty) throw Exception('Mee dura CV kee upload godhi.');
        await ApplyService().applyForJob(jobId: widget.jobId,
          applicantName: u['name'] ?? 'Applicant',
          applicantEmail: u['email'] ?? FirebaseAuth.instance.currentUser!.email ?? '',
          cvUrl: newCv);
      } else {
        await ApplyService().applyForJob(jobId: widget.jobId,
          applicantName: u['name'] ?? 'Applicant',
          applicantEmail: u['email'] ?? FirebaseAuth.instance.currentUser!.email ?? '',
          cvUrl: cvUrl);
      }
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Application kee ergamameera!')));
    } catch (e) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(e.toString())));
    } finally {
      if (mounted) setState(() => loading = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final d = widget.data;
    return Scaffold(
      appBar: AppBar(title: Text(d['title'] ?? 'Job details')),
      body: ListView(padding: const EdgeInsets.all(20), children: [
        Text(d['title'] ?? '', style: const TextStyle(fontSize: 28, fontWeight: FontWeight.bold)),
        const SizedBox(height: 8),
        Text(d['company'] ?? '', style: const TextStyle(fontSize: 18)),
        const SizedBox(height: 8),
        Text(d['location'] ?? ''),
        const SizedBox(height: 16),
        Text(d['description'] ?? 'No description'),
        const SizedBox(height: 25),
        FilledButton.icon(onPressed: loading ? null : apply,
          icon: const Icon(Icons.send), label: Text(loading ? 'Applying...' : 'Apply Now')),
      ]),
    );
  }
}
