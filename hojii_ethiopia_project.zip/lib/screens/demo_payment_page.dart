import 'package:flutter/material.dart';

class DemoPaymentPage extends StatefulWidget {
  final String jobId;
  final double amount;
  const DemoPaymentPage({super.key, required this.jobId, required this.amount});
  @override
  State<DemoPaymentPage> createState() => _DemoPaymentPageState();
}

class _DemoPaymentPageState extends State<DemoPaymentPage> {
  bool loading = false;
  Future<void> pay() async {
    setState(() => loading = true);
    await Future.delayed(const Duration(seconds: 2));
    if (!mounted) return;
    setState(() => loading = false);
    showDialog(context: context, builder: (_) => AlertDialog(
      title: const Text('Demo Payment Successful'),
      content: Text('${widget.amount} ETB demo payment. Qarshii dhugaa hin fudhatu.'),
      actions: [FilledButton(onPressed: () => Navigator.pop(context), child: const Text('Done'))],
    ));
  }
  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('Telebirr Demo')),
    body: Padding(padding: const EdgeInsets.all(24), child: Column(children: [
      const Icon(Icons.account_balance_wallet, size: 80),
      const SizedBox(height: 20),
      Text('${widget.amount} ETB', style: const TextStyle(fontSize: 30, fontWeight: FontWeight.bold)),
      const Spacer(),
      SizedBox(width: double.infinity, height: 52, child: FilledButton.icon(
        onPressed: loading ? null : pay, icon: const Icon(Icons.payment),
        label: Text(loading ? 'Processing...' : 'Pay with Telebirr (Demo)'),
      )),
    ])),
  );
}
