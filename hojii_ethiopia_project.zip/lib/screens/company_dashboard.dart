import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'applicants_page.dart';
import 'post_job_page.dart';

class CompanyDashboard extends StatelessWidget {
  const CompanyDashboard({super.key});
  @override
  Widget build(BuildContext context) {
    final uid = FirebaseAuth.instance.currentUser!.uid;
    return Scaffold(
      appBar: AppBar(title: const Text('Company Dashboard'), actions: [
        IconButton(icon: const Icon(Icons.logout), onPressed: () => FirebaseAuth.instance.signOut())
      ]),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const PostJobPage())),
        icon: const Icon(Icons.add), label: const Text('Post Job'),
      ),
      body: StreamBuilder<QuerySnapshot<Map<String, dynamic>>>(
        stream: FirebaseFirestore.instance.collection('jobs').where('ownerId', isEqualTo: uid).snapshots(),
        builder: (_, snap) {
          if (!snap.hasData) return const Center(child: CircularProgressIndicator());
          final jobs = snap.data!.docs;
          if (jobs.isEmpty) return const Center(child: Text('Hojii hin maxxansine.'));
          return ListView.builder(padding: const EdgeInsets.all(12), itemCount: jobs.length, itemBuilder: (_, i) {
            final d = jobs[i].data();
            return Card(child: ListTile(
              title: Text(d['title'] ?? ''),
              subtitle: Text(d['location'] ?? ''),
              trailing: const Icon(Icons.people),
              onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => ApplicantsPage(jobId: jobs[i].id))),
            ));
          });
        },
      ),
    );
  }
}
