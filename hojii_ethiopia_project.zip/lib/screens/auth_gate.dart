import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import '../services/role_service.dart';
import 'login_page.dart';
import 'home_page.dart';
import 'company_dashboard.dart';
import 'admin_dashboard.dart';

class AuthGate extends StatelessWidget {
  const AuthGate({super.key});

  @override
  Widget build(BuildContext context) {
    return StreamBuilder<User?>(
      stream: FirebaseAuth.instance.authStateChanges(),
      builder: (context, snapshot) {
        if (snapshot.connectionState == ConnectionState.waiting) {
          return const Scaffold(body: Center(child: CircularProgressIndicator()));
        }
        if (!snapshot.hasData) return const LoginPage();

        return FutureBuilder<String>(
          future: RoleService().getCurrentRole(),
          builder: (context, roleSnapshot) {
            if (!roleSnapshot.hasData) {
              return const Scaffold(body: Center(child: CircularProgressIndicator()));
            }
            switch (roleSnapshot.data) {
              case 'admin':
                return const AdminDashboard();
              case 'company':
                return const CompanyDashboard();
              default:
                return const HomePage();
            }
          },
        );
      },
    );
  }
}
