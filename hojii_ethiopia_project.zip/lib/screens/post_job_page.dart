import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';

class PostJobPage extends StatefulWidget {
  const PostJobPage({super.key});
  @override
  State<PostJobPage> createState() => _PostJobPageState();
}
class _PostJobPageState extends State<PostJobPage> {
  final title = TextEditingController(), company = TextEditingController(),
      location = TextEditingController(), salary = TextEditingController(),
      description = TextEditingController();
  bool loading = false;

  Future<void> save() async {
    setState(() => loading = true);
    try {
      await FirebaseFirestore.instance.collection('jobs').add({
        'title': title.text.trim(),
        'company': company.text.trim(),
        'location': location.text.trim(),
        'salary': salary.text.trim(),
        'description': description.text.trim(),
        'ownerId': FirebaseAuth.instance.currentUser!.uid,
        'isPremium': false,
        'createdAt': FieldValue.serverTimestamp(),
      });
      if (mounted) Navigator.pop(context);
    } finally { if (mounted) setState(() => loading = false); }
  }

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('Post Job')),
    body: ListView(padding: const EdgeInsets.all(20), children: [
      for (final x in [
        (title, 'Job title'), (company, 'Company'), (location, 'Location'),
        (salary, 'Salary'), (description, 'Description')
      ]) ...[
        TextField(controller: x.$1, decoration: InputDecoration(labelText: x.$2)),
        const SizedBox(height: 12),
      ],
      FilledButton(onPressed: loading ? null : save, child: Text(loading ? 'Saving...' : 'Publish Job')),
    ]),
  );
}
