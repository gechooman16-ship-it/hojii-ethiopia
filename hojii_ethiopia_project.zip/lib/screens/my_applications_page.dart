import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';

class MyApplicationsPage extends StatelessWidget {
  const MyApplicationsPage({super.key});
  @override
  Widget build(BuildContext context) {
    final uid = FirebaseAuth.instance.currentUser?.uid;
    return Scaffold(
      appBar: AppBar(title: const Text('My Applications')),
      body: StreamBuilder<QuerySnapshot<Map<String, dynamic>>>(
        stream: FirebaseFirestore.instance.collection('applications').where('userId', isEqualTo: uid).snapshots(),
        builder: (_, snap) {
          if (!snap.hasData) return const Center(child: CircularProgressIndicator());
          final docs = snap.data!.docs;
          if (docs.isEmpty) return const Center(child: Text('Application hin qabdu.'));
          return ListView.builder(itemCount: docs.length, itemBuilder: (_, i) {
            final d = docs[i].data();
            return Card(child: ListTile(
              title: Text(d['applicantName'] ?? 'Application'),
              subtitle: Text('Job: ${d['jobId']}'),
              trailing: Text(d['status'] ?? 'pending'),
            ));
          });
        },
      ),
    );
  }
}
