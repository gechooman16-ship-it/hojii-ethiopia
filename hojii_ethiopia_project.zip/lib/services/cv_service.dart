import 'dart:typed_data';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_storage/firebase_storage.dart';

class CvService {
  Future<String> uploadCv({required Uint8List bytes}) async {
    final user = FirebaseAuth.instance.currentUser;
    if (user == null) throw Exception('Mee login godhi.');
    final ref = FirebaseStorage.instance.ref('cv/${user.uid}/resume.pdf');
    await ref.putData(bytes, SettableMetadata(contentType: 'application/pdf'));
    return ref.getDownloadURL();
  }

  Future<void> deleteCv() async {
    final user = FirebaseAuth.instance.currentUser;
    if (user == null) throw Exception('User hin jiru.');
    try {
      await FirebaseStorage.instance.ref('cv/${user.uid}/resume.pdf').delete();
    } catch (_) {}
  }
}
