import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';

class RoleService {
  Future<String> getCurrentRole() async {
    final user = FirebaseAuth.instance.currentUser;
    if (user == null) return 'guest';
    final doc = await FirebaseFirestore.instance.collection('users').doc(user.uid).get();
    return doc.data()?['role'] ?? 'jobseeker';
  }
}
