import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';

class ApplyService {
  Future<void> applyForJob({
    required String jobId,
    required String applicantName,
    required String applicantEmail,
    required String cvUrl,
  }) async {
    final user = FirebaseAuth.instance.currentUser;
    if (user == null) throw Exception('Mee login godhi.');

    final existing = await FirebaseFirestore.instance.collection('applications')
        .where('jobId', isEqualTo: jobId)
        .where('userId', isEqualTo: user.uid)
        .limit(1).get();
    if (existing.docs.isNotEmpty) throw Exception('Ati duraan apply gooteetta.');

    await FirebaseFirestore.instance.collection('applications').add({
      'jobId': jobId,
      'userId': user.uid,
      'applicantName': applicantName,
      'applicantEmail': applicantEmail,
      'cvUrl': cvUrl,
      'status': 'pending',
      'createdAt': FieldValue.serverTimestamp(),
    });
  }
}
