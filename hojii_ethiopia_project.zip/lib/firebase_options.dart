// GENERATED FILE PLACEHOLDER.
//
// Do not put fake Firebase credentials here.
// Run:
//   dart pub global activate flutterfire_cli
//   flutterfire configure
//
// This command generates the real firebase_options.dart for your Firebase project.
