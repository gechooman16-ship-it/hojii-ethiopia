# Hojii Ethiopia

Flutter + Firebase starter project for an Ethiopian jobs marketplace.

## Features
- Email/password authentication
- Role-based routing: jobseeker, company, admin
- Jobs list and job details
- Apply to jobs
- My applications
- Company dashboard and applicants
- CV PDF upload to Firebase Storage
- Demo premium-payment screen (NOT a real Telebirr integration)
- Admin dashboard

## Setup
1. Install Flutter and Firebase CLI.
2. From this folder run:
   `flutter pub get`
3. Configure Firebase:
   `dart pub global activate flutterfire_cli`
   `flutterfire configure`
4. Enable Email/Password Authentication, Firestore and Storage in Firebase Console.
5. The generated `lib/firebase_options.dart` is intentionally not included.
6. Run:
   `flutter run`

## Build APK
`flutter build apk --release`

## Build web
`flutter build web --release`

Important: Demo payment does not move real money. A real Telebirr merchant/API integration requires approved merchant credentials and a secure backend/webhook.
